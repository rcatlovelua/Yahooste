package com.yahoostee.mixin;

import com.yahoostee.client.YahoosteePanel;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_408.class)
public abstract class ChatScreenMixin extends class_437 {
    @Shadow
    protected class_342 chatField;

    protected ChatScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        // Инициализируем панель при открытии чата и добавляем элементы управления
        YahoosteePanel.init((class_408) (Object) this, this.field_22789, this.field_22790, this::method_37063, this.chatField);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        // Отрисовываем фон под панелью на этапе HEAD, чтобы кнопки рендерились поверх фона
        YahoosteePanel.drawBackground(context, this.field_22789, this.field_22790);
    }
}
