package com.yahoostee.client;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;

public class TickerButtonWidget extends class_339 {
    private final class_2561 fullMessage;
    private final PressAction onPress;
    private float scrollOffset = 0.0f;
    private long lastTime = 0;
    private boolean scrollForward = true;

    public interface PressAction {
        void onPress(TickerButtonWidget button);
    }

    public TickerButtonWidget(int x, int y, int width, int height, class_2561 message, PressAction onPress) {
        super(x, y, width, height, message);
        this.fullMessage = message;
        this.onPress = onPress;
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        // Рисуем рамку кнопки (ванильный стиль)
        this.renderButton(context, mouseX, mouseY);

        class_327 textRenderer = class_310.method_1551().field_1772;
        var orderedText = this.fullMessage.method_30937();
        int textWidth = textRenderer.method_30880(orderedText);
        int padding = 6;
        int maxTextWidth = this.method_25368() - padding * 2;

        int textX = this.method_46426() + padding;
        int textY = this.method_46427() + (this.method_25364() - 8) / 2;
        int textColor = this.field_22763 ? 0xFFFFFF : 0xA0A0A0;

        if (textWidth <= maxTextWidth) {
            int centeredX = this.method_46426() + (this.method_25368() - textWidth) / 2;
            context.method_51430(textRenderer, orderedText, centeredX, textY, textColor, true);
        } else {
            long currentTime = System.currentTimeMillis();
            if (lastTime == 0) lastTime = currentTime;
            long elapsed = currentTime - lastTime;
            lastTime = currentTime;

            float maxScroll = textWidth - maxTextWidth;
            float speed = 0.05f;

            if (scrollForward) {
                scrollOffset += speed * elapsed;
                if (scrollOffset >= maxScroll + 15) {
                    scrollOffset = maxScroll + 15;
                    scrollForward = false;
                }
            } else {
                scrollOffset -= speed * elapsed;
                if (scrollOffset <= -15) {
                    scrollOffset = -15;
                    scrollForward = true;
                }
            }
            float displayOffset = Math.max(0, Math.min(maxScroll, scrollOffset));

            context.method_44379(this.method_46426() + padding, this.method_46427(), this.method_46426() + this.method_25368() - padding, this.method_46427() + this.method_25364());
            context.method_51430(textRenderer, orderedText, (int) (textX - displayOffset), textY, textColor, true);
            context.method_44380();
        }
    }

    private void renderButton(class_332 context, int mouseX, int mouseY) {
        // Упрощенная отрисовка фона кнопки
        int color = method_49606() ? 0xFFFF0000 : 0xFF00FF00;
        context.method_25294(method_46426(), method_46427(), method_46426() + method_25368(), method_46427() + method_25364(), color);
    }

    public void onClick(double mouseX, double mouseY) {
        this.onPress.onPress(this);
    }

    @Override
    protected void method_47399(net.minecraft.class_6382 builder) {
        this.method_37021(builder);
    }
}
