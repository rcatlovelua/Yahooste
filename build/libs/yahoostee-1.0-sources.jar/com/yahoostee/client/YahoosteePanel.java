package com.yahoostee.client;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_4185;

public class YahoosteePanel {
    // Размеры и отступы
    private static final int PANEL_WIDTH = 210;
    private static final int ELEMENT_HEIGHT = 20; 
    private static final int SPACING = 4;
    private static final int MARGIN_RIGHT = 6;
    private static final int MARGIN_BOTTOM = 90; // Поднято над субтитрами

    // Внутреннее состояние панели
    private static String savedCoords = "";
    private static String currentCustomText = ""; // Сохраняем текст верхнего поля при перезагрузке UI
    private static int currentActionIndex = 0;
    
    private static final List<CustomBtn> customButtons = new ArrayList<>();

    // --- ФАЙЛОВЫЕ ПУТИ ---

    private static Path getSavePath() {
        return class_310.method_1551().field_1697.toPath().resolve("yahoostee_nether_coords.txt");
    }

    private static Path getMacrosPath() {
        return class_310.method_1551().field_1697.toPath().resolve("yahoostee_macros.txt");
    }

    // --- ЗАГРУЗКА И СОХРАНЕНИЕ ---

    private static void loadFiles() {
        try {
            // Координаты
            Path coordsPath = getSavePath();
            if (Files.exists(coordsPath)) {
                savedCoords = Files.readString(coordsPath).trim();
            }

            // Макросы (Кастомные кнопки)
            customButtons.clear();
            Path macrosPath = getMacrosPath();
            if (Files.exists(macrosPath)) {
                List<String> lines = Files.readAllLines(macrosPath);
                for (String line : lines) {
                    String[] parts = line.split("\\|", 2);
                    if (parts.length == 2) {
                        try {
                            customButtons.add(new CustomBtn(Action.valueOf(parts[0]), parts[1]));
                        } catch (Exception ignored) {} // Игнорируем битые строки
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("YahoosteePanel: Ошибка загрузки файлов: " + e.getMessage());
        }
    }

    private static void saveCoords(String coords) {
        savedCoords = coords;
        try { Files.writeString(getSavePath(), coords); } 
        catch (Exception ignored) {}
    }

    private static void saveMacros() {
        try {
            List<String> lines = new ArrayList<>();
            for (CustomBtn btn : customButtons) {
                lines.add(btn.action.name() + "|" + btn.payload);
            }
            Files.write(getMacrosPath(), lines);
        } catch (Exception ignored) {}
    }

    // --- ДИНАМИЧЕСКАЯ ВЫСОТА ---

    private static int getPanelHeight() {
        // 2 текстовых поля + 4 базовые кнопки + 1 строка создания макроса = 7 базовых элементов
        int totalElements = 7 + customButtons.size();
        return totalElements * ELEMENT_HEIGHT + (totalElements + 1) * SPACING;
    }

    // --- ПЕРЕЗАГРУЗКА ИНТЕРФЕЙСА ---
    // Используется для моментального обновления чата при добавлении/удалении кнопок
    private static void reloadScreen(class_342 chatField) {
        String currentChat = chatField.method_1882();
        class_310.method_1551().method_1507(new class_408(currentChat, false));
    }

    // --- ИНИЦИАЛИЗАЦИЯ GUI ---

    public static void init(class_408 screen, int screenWidth, int screenHeight, 
                            Consumer<class_339> widgetAdder,
                            class_342 chatField) {
        
        loadFiles();
        
        int panelHeight = getPanelHeight();
        int x = screenWidth - PANEL_WIDTH - MARGIN_RIGHT;
        int y = screenHeight - MARGIN_BOTTOM - panelHeight;
        int currentY = y + SPACING;
        int elemWidth = PANEL_WIDTH - SPACING * 2;

        // 1. Поле для кастомного текста
        class_342 customTextField = new class_342(class_310.method_1551().field_1772, 
                x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT, class_2561.method_43473());
        customTextField.method_1880(256);
        customTextField.method_47404(class_2561.method_43470("Кастомный текст..."));
        customTextField.method_1852(currentCustomText);
        customTextField.method_1863(text -> currentCustomText = text);
        widgetAdder.accept(customTextField);
        currentY += ELEMENT_HEIGHT + SPACING;

        // 2. Поле для СОХРАНЕННЫХ КООРДИНАТ
        class_342 coordsTextField = new class_342(class_310.method_1551().field_1772, 
                x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT, class_2561.method_43473());
        coordsTextField.method_1880(100);
        coordsTextField.method_47404(class_2561.method_43470("Координаты для отправки..."));
        coordsTextField.method_1852(savedCoords);
        coordsTextField.method_1863(YahoosteePanel::saveCoords); 
        widgetAdder.accept(coordsTextField);
        currentY += ELEMENT_HEIGHT + SPACING;

        // 3. Базовые кнопки
        widgetAdder.accept(class_4185.method_46430(class_2561.method_43470("Записать текущие коорд. в поле"), btn -> {
            coordsTextField.method_1852(getCoords(true));
        }).method_46434(x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT).method_46431());
        currentY += ELEMENT_HEIGHT + SPACING;

        widgetAdder.accept(class_4185.method_46430(class_2561.method_43470("Вставить коорд. из поля в чат"), btn -> {
            if (!coordsTextField.method_1882().isEmpty()) chatField.method_1867(coordsTextField.method_1882());
        }).method_46434(x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT).method_46431());
        currentY += ELEMENT_HEIGHT + SPACING;

        widgetAdder.accept(class_4185.method_46430(class_2561.method_43470("Вставить свою текущую позицию"), btn -> {
            chatField.method_1867(getCoords(false));
        }).method_46434(x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT).method_46431());
        currentY += ELEMENT_HEIGHT + SPACING;

        widgetAdder.accept(class_4185.method_46430(class_2561.method_43470("Текст из верхнего поля в чат"), btn -> {
            if (!customTextField.method_1882().isEmpty()) chatField.method_1867(customTextField.method_1882());
        }).method_46434(x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT).method_46431());
        currentY += ELEMENT_HEIGHT + SPACING;

        // 4. СТРОКА СОЗДАНИЯ КАСТОМНОЙ КНОПКИ (Цикличная кнопка выбора + Добавление)
        int actionBtnWidth = elemWidth - 24;
        
        class_4185 actionCycler = class_4185.method_46430(class_2561.method_43470("Действие: " + Action.values()[currentActionIndex].displayName), btn -> {
            currentActionIndex = (currentActionIndex + 1) % Action.values().length;
            btn.method_25355(class_2561.method_43470("Действие: " + Action.values()[currentActionIndex].displayName));
        }).method_46434(x + SPACING, currentY, actionBtnWidth, ELEMENT_HEIGHT).method_46431();
        widgetAdder.accept(actionCycler);

        widgetAdder.accept(class_4185.method_46430(class_2561.method_43470("+"), btn -> {
            if (customButtons.size() >= 5) return; // Лимит в 5 кнопок
            
            String payload = customTextField.method_1882();
            Action selectedAction = Action.values()[currentActionIndex];
            if (selectedAction == Action.PASTE_TEXT && payload.isEmpty()) {
                payload = "Пусто";
            }
            
            customButtons.add(new CustomBtn(selectedAction, payload));
            saveMacros();
            reloadScreen(chatField); // Перезагружаем интерфейс чтобы кнопка появилась
        }).method_46434(x + SPACING + actionBtnWidth + 4, currentY, 20, ELEMENT_HEIGHT).method_46431());
        currentY += ELEMENT_HEIGHT + SPACING;

        // 5. РЕНДЕР СОХРАНЕННЫХ КАСТОМНЫХ КНОПОК
        for (int i = 0; i < customButtons.size(); i++) {
            CustomBtn cb = customButtons.get(i);
            int finalI = i;

            // Сама кнопка действия
            widgetAdder.accept(class_4185.method_46430(class_2561.method_43470(cb.getLabel()), btn -> {
                cb.execute(chatField);
            }).method_46434(x + SPACING, currentY, actionBtnWidth, ELEMENT_HEIGHT).method_46431());

            // Кнопка удаления [x]
            widgetAdder.accept(class_4185.method_46430(class_2561.method_43470("x"), btn -> {
                customButtons.remove(finalI);
                saveMacros();
                reloadScreen(chatField); // Обновляем экран для скрытия
            }).method_46434(x + SPACING + actionBtnWidth + 4, currentY, 20, ELEMENT_HEIGHT).method_46431());

            currentY += ELEMENT_HEIGHT + SPACING;
        }
    }

    public static void drawBackground(class_332 context, int screenWidth, int screenHeight) {
        int panelHeight = getPanelHeight();
        int x = screenWidth - PANEL_WIDTH - MARGIN_RIGHT;
        int y = screenHeight - MARGIN_BOTTOM - panelHeight;

        context.method_25294(x, y, x + PANEL_WIDTH, y + panelHeight, 0xAA080808);
        
        int borderColor = 0xFF353535;
        context.method_25294(x, y, x + PANEL_WIDTH, y + 1, borderColor); 
        context.method_25294(x, y + panelHeight - 1, x + PANEL_WIDTH, y + panelHeight, borderColor); 
        context.method_25294(x, y, x + 1, y + panelHeight, borderColor); 
        context.method_25294(x + PANEL_WIDTH - 1, y, x + PANEL_WIDTH, y + panelHeight, borderColor); 
    }

    private static String getCoords(boolean divideIfOverworld) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return "0 0 0";

        int x = client.field_1724.method_31477();
        int y = client.field_1724.method_31478();
        int z = client.field_1724.method_31479();

        boolean isNether = client.field_1687.method_27983() == class_1937.field_25180;
        if (divideIfOverworld && !isNether) {
            x /= 8; z /= 8;
        }
        return x + " " + y + " " + z;
    }

    // --- КЛАССЫ ДЛЯ СИСТЕМЫ МАКРОСОВ ---

    private enum Action {
        PASTE_TEXT("Вставить текст"),
        PASTE_COORDS("Вставить сохр. коорд."),
        PASTE_POS("Вставить свою позицию");

        final String displayName;
        Action(String displayName) { this.displayName = displayName; }
    }

    private static class CustomBtn {
        Action action;
        String payload;

        CustomBtn(Action action, String payload) {
            this.action = action;
            this.payload = payload;
        }

        String getLabel() {
            if (action == Action.PASTE_TEXT) {
                String t = payload;
                if (t.length() > 14) t = t.substring(0, 14) + "...";
                return "Текст: " + t;
            }
            return action.displayName;
        }

        void execute(class_342 chatField) {
            switch (action) {
                case PASTE_TEXT: 
                    chatField.method_1867(payload); 
                    break;
                case PASTE_COORDS: 
                    if (!savedCoords.isEmpty()) chatField.method_1867(savedCoords); 
                    break;
                case PASTE_POS: 
                    chatField.method_1867(getCoords(false)); 
                    break;
            }
        }
    }
}