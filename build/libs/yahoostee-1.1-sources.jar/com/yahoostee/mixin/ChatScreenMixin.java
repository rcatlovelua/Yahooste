package com.yahoostee.mixin;

import com.yahoostee.client.YahoosteePanel;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public abstract class ChatScreenMixin extends class_437 {
    
    @Shadow
    protected class_342 chatField;

    protected ChatScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        YahoosteePanel.init((class_408) (Object) this, this.field_22789, this.field_22790, this::method_37063, this.chatField);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        YahoosteePanel.drawBackground(context, this.field_22789, this.field_22790);
    }
    
    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void onKeyPressed(class_11908 input, CallbackInfoReturnable<Boolean> cir) {
        int key = input.comp_4795();

        // Блокируем ВСЁ - навигацию, Enter, Backspace
        if (key == GLFW.GLFW_KEY_TAB ||
        key == GLFW.GLFW_KEY_UP ||
            key == GLFW.GLFW_KEY_DOWN ||
            key == GLFW.GLFW_KEY_LEFT ||
            key == GLFW.GLFW_KEY_RIGHT ||
            key == GLFW.GLFW_KEY_PAGE_UP ||
            key == GLFW.GLFW_KEY_PAGE_DOWN ||
            key == GLFW.GLFW_KEY_HOME ||
            key == GLFW.GLFW_KEY_END ||
            key == GLFW.GLFW_KEY_ENTER ||
            key == GLFW.GLFW_KEY_KP_ENTER ||
            key == GLFW.GLFW_KEY_BACKSPACE) {  // Добавили Backspace
            
            cir.setReturnValue(true);
        }
    }
}