package com.yahoostee.client;

import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.logging.Logger;
import net.minecraft.class_11908;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_4185;

public class YahoosteePanel {
    private static final Logger LOGGER = Logger.getLogger("YahoosteePanel");

    // Размеры и отступы
    private static final int PANEL_WIDTH = 230;
    private static final int ELEMENT_HEIGHT = 20;
    private static final int SPACING = 4;
    private static final int MARGIN_RIGHT = 6;
    private static final int MARGIN_BOTTOM = 90;
    private static final int MAX_MACROS = 5;

    // Количество фиксированных строк интерфейса (не считая кастомных макросов):
    // 1) поле кастомного текста, 2) поле координат, 3) "Записать позицию",
    // 4) строка "Вставить коорд." / "Вставить позицию", 5) "Вставить текст из поля",
    // 6) разделитель, 7) строка из 3 кнопок создания макросов
    private static final int FIXED_ROWS = 7;

    // Внутреннее состояние панели
    private static String savedCoords = "";
    private static String currentCustomText = "";
    private static final List<CustomBtn> customButtons = new ArrayList<>();

    // Все виджеты, принадлежащие панели (кнопки, поля панели).
    // По ним отличаем "фокус на нашем интерфейсе" от "фокус на chatField".
    private static final java.util.Set<class_339> panelWidgets =
            java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<>());

    /**
     * true, если сейчас в фокусе именно виджет нашей панели
     * (кнопка, поле координат, поле кастомного текста и т.п.),
     * а не обычное поле ввода сообщения (chatField).
     */
    public static boolean isPanelWidgetFocused(net.minecraft.class_437 screen) {
        var focused = screen.method_25399();
        return focused instanceof class_339 widget && panelWidgets.contains(widget);
    }

    // --- ФАЙЛОВЫЕ ПУТИ ---
    private static Path getSavePath() {
        return class_310.method_1551().field_1697.toPath().resolve("yahoostee_nether_coords.txt");
    }

    private static Path getMacrosPath() {
        return class_310.method_1551().field_1697.toPath().resolve("yahoostee_macros.txt");
    }

    // --- ЗАГРУЗКА И СОХРАНЕНИЕ ---
    private static void loadFiles() {
        try {
            Path coordsPath = getSavePath();
            if (Files.exists(coordsPath)) {
                savedCoords = Files.readString(coordsPath).trim();
            }

            customButtons.clear();
            Path macrosPath = getMacrosPath();
            if (Files.exists(macrosPath)) {
                List<String> lines = Files.readAllLines(macrosPath);
                for (String line : lines) {
                    String[] parts = line.split("\\|", 2);
                    if (parts.length == 2) {
                        try {
                            customButtons.add(new CustomBtn(Action.valueOf(parts[0]), parts[1]));
                        } catch (Exception ignored) {}
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.warning("YahoosteePanel: ошибка загрузки файлов: " + e.getMessage());
        }
    }

    private static void saveCoords(String coords) {
        savedCoords = coords;
        try {
            Files.writeString(getSavePath(), coords);
        } catch (Exception e) {
            LOGGER.warning("YahoosteePanel: не удалось сохранить координаты: " + e.getMessage());
        }
    }

    private static void saveMacros() {
        try {
            List<String> lines = new ArrayList<>();
            for (CustomBtn btn : customButtons) {
                lines.add(btn.action.name() + "|" + btn.payload);
            }
            Files.write(getMacrosPath(), lines);
        } catch (Exception e) {
            LOGGER.warning("YahoosteePanel: не удалось сохранить макросы: " + e.getMessage());
        }
    }

    // --- ДИНАМИЧЕСКАЯ ВЫСОТА ---
    private static int getPanelHeight() {
        int totalElements = FIXED_ROWS + customButtons.size();
        return totalElements * ELEMENT_HEIGHT + (totalElements + 1) * SPACING;
    }

    // --- ПЕРЕЗАГРУЗКА ИНТЕРФЕЙСА ---
    private static void reloadScreen(class_342 chatField) {
        String currentChat = chatField.method_1882();
        class_310.method_1551().method_1507(new class_408(currentChat, false));
    }

    // --- ОБЩАЯ ЛОГИКА "ВЫКЛЮЧЕННЫХ" КЛАВИШ ---
    // Tab / Enter / стрелки не должны утекать в остальной интерфейс чата
    // (автодополнение ников, отправка сообщения, история сообщений и т.д.)
    private static boolean isNavigationKey(int keyCode) {
        return keyCode == GLFW.GLFW_KEY_TAB
                || keyCode == GLFW.GLFW_KEY_ENTER
                || keyCode == GLFW.GLFW_KEY_KP_ENTER
                || keyCode == GLFW.GLFW_KEY_LEFT
                || keyCode == GLFW.GLFW_KEY_RIGHT
                || keyCode == GLFW.GLFW_KEY_UP
                || keyCode == GLFW.GLFW_KEY_DOWN;
    }

    // --- СОЗДАНИЕ КНОПОК С ОТКЛЮЧЕНИЕМ ФОКУСА ---
    // Используем стандартный builder ButtonWidget — субклассирование через
    // protected-конструктор не переносимо между версиями маппингов и ломает сборку.
    private static class_4185 createButton(String text, int x, int y, int width, Runnable action) {
        class_4185 button = class_4185.method_46430(class_2561.method_43470(text), btn -> action.run())
                .method_46434(x, y, width, ELEMENT_HEIGHT)
                .method_46431();
        button.method_25365(false);
        return button;
    }

    // --- УПРОЩЕННЫЙ КАСТОМНЫЙ TextFieldWidget ---
    private static class NoFocusTextField extends class_342 {
        public NoFocusTextField(net.minecraft.class_327 textRenderer, int x, int y, int width, int height, class_2561 text) {
            super(textRenderer, x, y, width, height, text);
            this.method_25365(false);
        }

        // Всегда сбрасываем фокус
        @Override
        public void method_25365(boolean focused) {
            super.method_25365(false);
        }

        // Просто возвращаем false и сбрасываем фокус.
        // Без @Override: в некоторых версиях Minecraft сигнатура обработки клика мыши
        // у TextFieldWidget отличается от (double, double, int) — как и в исходном файле,
        // оставляем это как есть, чтобы не ломать сборку под конкретную версию маппингов.
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            this.method_25365(false);
            return false;
        }

        // Tab/Enter/стрелки не должны переключать фокус экрана
        // или дёргать отправку сообщения/автодополнение.
        // С 1.21.9+ Minecraft передаёт клавишу единым объектом KeyInput вместо трёх int.
        @Override
        public boolean method_25404(class_11908 input) {
            if (isNavigationKey(input.comp_4795())) {
                return true; // клавиша "выключена" для этого поля
            }
            return super.method_25404(input);
        }
    }

    // --- ИНИЦИАЛИЗАЦИЯ GUI ---
    public static void init(class_408 screen, int screenWidth, int screenHeight,
                            Consumer<class_339> widgetAdder,
                            class_342 chatField) {

        loadFiles();

        int panelHeight = getPanelHeight();
        int x = screenWidth - PANEL_WIDTH - MARGIN_RIGHT;
        int y = screenHeight - MARGIN_BOTTOM - panelHeight;
        int currentY = y + SPACING;
        int elemWidth = PANEL_WIDTH - SPACING * 2;
        int buttonWidth = (elemWidth - SPACING) / 2;

        // 1. Поле для кастомного текста
        NoFocusTextField customTextField = new NoFocusTextField(
                class_310.method_1551().field_1772,
                x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT, class_2561.method_43473()
        );
        customTextField.method_1880(256);
        customTextField.method_47404(class_2561.method_43470("Кастомный текст..."));
        customTextField.method_1852(currentCustomText);
        customTextField.method_1863(text -> currentCustomText = text);
        widgetAdder.accept(customTextField);
        currentY += ELEMENT_HEIGHT + SPACING;

        // 2. Поле для координат
        NoFocusTextField coordsTextField = new NoFocusTextField(
                class_310.method_1551().field_1772,
                x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT, class_2561.method_43473()
        );
        coordsTextField.method_1880(100);
        coordsTextField.method_47404(class_2561.method_43470("Координаты для отправки..."));
        coordsTextField.method_1852(savedCoords);
        coordsTextField.method_1863(YahoosteePanel::saveCoords);
        widgetAdder.accept(coordsTextField);
        currentY += ELEMENT_HEIGHT + SPACING;

        // 3. Базовые кнопки
        widgetAdder.accept(createButton("Записать позицию", x + SPACING, currentY, elemWidth, () -> {
            coordsTextField.method_1852(getCoords(true));
        }));
        currentY += ELEMENT_HEIGHT + SPACING;

        widgetAdder.accept(createButton("Вставить коорд.", x + SPACING, currentY, buttonWidth, () -> {
            if (!coordsTextField.method_1882().isEmpty()) chatField.method_1867(coordsTextField.method_1882());
        }));

        widgetAdder.accept(createButton("Вставить позицию", x + SPACING + buttonWidth + SPACING, currentY, buttonWidth, () -> {
            chatField.method_1867(getCoords(false));
        }));
        currentY += ELEMENT_HEIGHT + SPACING;

        widgetAdder.accept(createButton("Вставить текст из поля", x + SPACING, currentY, elemWidth, () -> {
            if (!customTextField.method_1882().isEmpty()) chatField.method_1867(customTextField.method_1882());
        }));
        currentY += ELEMENT_HEIGHT + SPACING;

        // 4. Разделитель (декоративный, без действия)
        class_4185 divider = class_4185.method_46430(class_2561.method_43470("═══════ Макросы ═══════"), btn -> {})
                .method_46434(x + SPACING, currentY, elemWidth, ELEMENT_HEIGHT)
                .method_46431();
        divider.method_25365(false);
        widgetAdder.accept(divider);
        currentY += ELEMENT_HEIGHT + SPACING;

        // 5. Кнопки создания макросов
        int macroBtnWidth = (elemWidth - SPACING * 2) / 3;

        widgetAdder.accept(createButton("📝 Текст", x + SPACING, currentY, macroBtnWidth, () -> {
            if (customButtons.size() >= MAX_MACROS) return;
            String payload = customTextField.method_1882();
            if (payload.isEmpty()) payload = "Пусто";
            customButtons.add(new CustomBtn(Action.PASTE_TEXT, payload));
            saveMacros();
            reloadScreen(chatField);
        }));

        widgetAdder.accept(createButton("📌 Коорд.", x + SPACING + macroBtnWidth + SPACING, currentY, macroBtnWidth, () -> {
            if (customButtons.size() >= MAX_MACROS) return;
            customButtons.add(new CustomBtn(Action.PASTE_COORDS, ""));
            saveMacros();
            reloadScreen(chatField);
        }));

        widgetAdder.accept(createButton("📍 Позиция", x + SPACING + (macroBtnWidth + SPACING) * 2, currentY, macroBtnWidth, () -> {
            if (customButtons.size() >= MAX_MACROS) return;
            customButtons.add(new CustomBtn(Action.PASTE_POS, ""));
            saveMacros();
            reloadScreen(chatField);
        }));
        currentY += ELEMENT_HEIGHT + SPACING;

        // 6. Кастомные кнопки
        for (int i = 0; i < customButtons.size(); i++) {
            CustomBtn cb = customButtons.get(i);
            int finalI = i;

            class_4185 actionBtn = createButton(cb.getLabel(), x + SPACING, currentY, elemWidth - 24, () -> cb.execute(chatField));
            widgetAdder.accept(actionBtn);

            class_4185 deleteBtn = createButton("✕", x + SPACING + elemWidth - 24, currentY, 20, () -> {
                customButtons.remove(finalI);
                saveMacros();
                reloadScreen(chatField);
            });
            widgetAdder.accept(deleteBtn);

            currentY += ELEMENT_HEIGHT + SPACING;
        }
    }

    public static void drawBackground(class_332 context, int screenWidth, int screenHeight) {
        int panelHeight = getPanelHeight();
        int x = screenWidth - PANEL_WIDTH - MARGIN_RIGHT;
        int y = screenHeight - MARGIN_BOTTOM - panelHeight;

        context.method_25294(x, y, x + PANEL_WIDTH, y + panelHeight, 0xCC0A0A0A);

        int borderColor = 0xFF555555;
        context.method_25294(x, y, x + PANEL_WIDTH, y + 1, borderColor);
        context.method_25294(x, y + panelHeight - 1, x + PANEL_WIDTH, y + panelHeight, borderColor);
        context.method_25294(x, y, x + 1, y + panelHeight, borderColor);
        context.method_25294(x + PANEL_WIDTH - 1, y, x + PANEL_WIDTH, y + panelHeight, borderColor);
        context.method_25294(x + 1, y + 1, x + PANEL_WIDTH - 1, y + 2, 0x33222222);
    }

    private static String getCoords(boolean divideIfOverworld) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return "0 0 0";

        int x = client.field_1724.method_31477();
        int y = client.field_1724.method_31478();
        int z = client.field_1724.method_31479();

        boolean isNether = client.field_1687.method_27983() == class_1937.field_25180;
        if (divideIfOverworld && !isNether) {
            x /= 8;
            z /= 8;
        }
        return x + " " + y + " " + z;
    }

    // --- КЛАССЫ ДЛЯ СИСТЕМЫ МАКРОСОВ ---
    private enum Action {
        PASTE_TEXT("Вставить текст"),
        PASTE_COORDS("Вставить коорд."),
        PASTE_POS("Вставить позицию");

        final String displayName;

        Action(String displayName) {
            this.displayName = displayName;
        }
    }

    private static class CustomBtn {
        Action action;
        String payload;

        CustomBtn(Action action, String payload) {
            this.action = action;
            this.payload = payload;
        }

        String getLabel() {
            if (action == Action.PASTE_TEXT) {
                String t = payload;
                if (t.length() > 14) t = t.substring(0, 14) + "...";
                return "📝 " + t;
            } else if (action == Action.PASTE_COORDS) {
                return "📌 Координаты";
            } else {
                return "📍 Позиция";
            }
        }

        void execute(class_342 chatField) {
            switch (action) {
                case PASTE_TEXT:
                    chatField.method_1867(payload);
                    break;
                case PASTE_COORDS:
                    if (!savedCoords.isEmpty()) chatField.method_1867(savedCoords);
                    break;
                case PASTE_POS:
                    chatField.method_1867(getCoords(false));
                    break;
            }
        }
    }
}