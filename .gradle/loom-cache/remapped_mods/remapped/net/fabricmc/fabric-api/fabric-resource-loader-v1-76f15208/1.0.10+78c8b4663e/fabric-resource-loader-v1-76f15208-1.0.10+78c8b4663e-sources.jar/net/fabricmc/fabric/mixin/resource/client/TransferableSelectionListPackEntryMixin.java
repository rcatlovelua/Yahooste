/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.resource.client;

import java.util.List;
import java.util.Optional;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.fabric.impl.resource.client.PackTooltipComponent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.pack.PackListWidget;
import net.minecraft.client.gui.widget.MultilineTextWidget;
import net.minecraft.client.gui.widget.TextWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

@Mixin(PackListWidget.ResourcePackEntry.class)
class TransferableSelectionListPackEntryMixin {
	@Shadow
	@Final
	private static int MAX_DESCRIPTION_WIDTH_PIXELS;

	@Shadow
	@Final
	protected MinecraftClient minecraft;

	@Shadow
	@Final
	private TextWidget nameWidget;

	@Shadow
	@Final
	private MultilineTextWidget descriptionWidget;

	@Shadow
	@Final
	PackListWidget field_62184;

	@Inject(method = "renderContent", at = @At("RETURN"))
	private void onRenderContent(
			DrawContext graphics, int mouseX, int mouseY, boolean hovered, float tickDelta, CallbackInfo ci
	) {
		if (hovered) {
			Text name = null;
			boolean includeDescription = false;

			if (this.nameWidget.getWidth() < this.minecraft.textRenderer.getWidth(this.nameWidget.getMessage().asOrderedText())) {
				name = this.nameWidget.getMessage();
			}

			List<OrderedText> splitDescription = this.minecraft.textRenderer.wrapLines(
					this.descriptionWidget.getMessage(),
					MAX_DESCRIPTION_WIDTH_PIXELS - (this.field_62184.getMaxScrollY() > 0 ? 6 : 0)
			);

			if (splitDescription.size() > 2) {
				includeDescription = true;
			}

			if (name != null || includeDescription) {
				graphics.drawTooltip(
						this.minecraft.textRenderer,
						List.of(),
						Optional.of(new PackTooltipComponent(
								Optional.ofNullable(name),
								includeDescription ? Optional.of(splitDescription) : Optional.empty()
						)),
						mouseX, mouseY
				);
			}
		}
	}
}
